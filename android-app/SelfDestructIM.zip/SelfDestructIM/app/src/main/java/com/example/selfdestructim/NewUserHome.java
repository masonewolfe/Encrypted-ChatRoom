package com.example.selfdestructim;
import android.os.Bundle;
import android.view.MenuItem;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.navigation.NavigationBarView;

public class NewUserHome extends AppCompatActivity
{
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.new_user_home);
        NavigationBarView bottomNav = findViewById(R.id.bottomNavigation);
        getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container, new Messages()).commit();
        bottomNav.getMenu().getItem(1).setChecked(true);
        bottomNav.setOnItemSelectedListener(new NavigationBarView.OnItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {

                Fragment selectedFragment = null;
                switch(item.getItemId())
                {
                    case R.id.groups: selectedFragment = new GroupChats();break;
                    case R.id.messages: selectedFragment = new Messages();break;
                    case R.id.profile: selectedFragment = new userProfile();break;
                    case R.id.addFriend: selectedFragment = new Friends(); break;
                }
                item.setChecked(true);
                getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container, selectedFragment).commit();
                return true;
            }
        });

    }
}
