package com.example.selfdestructim;
import android.os.AsyncTask;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.security.NoSuchAlgorithmException;
import java.util.Base64;

public class HttpRequests extends AsyncTask<String, String, String>
{
	private static String url = "http://3.91.204.251";



	//WILL SEND HTTP REQUEST TO EJABBERD TO REGISTER A USER
	//IF REQUEST RETURNS 200 THEN SUCCESS
	//OTHERWISE FAILED REGISTRATION
	public static int registerEjabberd(String username, String password)
	{
		try
		{
			URL ejabberdurl = new URL(url+":5281/api/register");
			String[] ids = {"user", "host", "password"};
			String[] vals = {username, "cipher.com", password};
			jsonObj json = new jsonObj(ids, vals);
			HttpURLConnection conn = (HttpURLConnection) ejabberdurl.openConnection();
			conn.setRequestMethod("POST");
			conn.setDoOutput(true);
			OutputStream os = conn.getOutputStream();
			os.write(json.toString().getBytes(StandardCharsets.UTF_8));
			int rc1 = conn.getResponseCode();
			conn.disconnect();
			return rc1;
		} catch (IOException e)
		{
			return -1;
		}

	}

	//WILL SEND HTTP REQUEST TO ADD USERS NEW PUBLIC KEY TO THE DATABASE
	//SHOULD BE USED AFTER CONFIRMING registerEjabber() HAS COMPLETED SUCCESSFULLY
	public static int registerPublicKey(String username, String email) throws IOException, NoSuchAlgorithmException
	{
		storage.generateKeyPair();
		URL keysurl = new URL(url+":5000/create");
		String[] ids2 = {"username", "email", "publickey"};
		String[] vals2 = {username, email, storage.pubKeyEncoded};
		jsonObj json2 = new jsonObj(ids2, vals2);
		HttpURLConnection conn2 =(HttpURLConnection) keysurl.openConnection();
		conn2.setDoOutput(true);
		conn2.setRequestMethod("POST");
		conn2.setRequestProperty("Accept", "application/json");
		conn2.setRequestProperty("Content-Type", "application/json");
		OutputStream os2 = conn2.getOutputStream();
		os2.write(json2.toString().getBytes(StandardCharsets.UTF_8));
		os2.flush();
		int rc2 = conn2.getResponseCode();
		conn2.disconnect();
		return rc2;
	}


	//WILL PULL A USERS PUBLIC KEY TO ENCRYPT MESSAGES SENT TO THEM
	public static String getUserKey (String username)
	{
		try
		{
			URL apiInterface = new URL(url+":5000/pull");
			String[] ids = {"username"};
			String[] vals = {username};
			jsonObj json = new jsonObj(ids, vals);
			HttpURLConnection conn = (HttpURLConnection) apiInterface.openConnection();
			conn.setDoOutput(true);
			conn.setDoInput(true);
			conn.setRequestMethod("POST");
			conn.setRequestProperty("Accept", "application/json");
			conn.setRequestProperty("Content-Type", "application/json");
			OutputStream os = conn.getOutputStream();
			os.write(json.toString().getBytes(StandardCharsets.UTF_8));
			os.flush();
			if(conn.getResponseCode() == 200)
			{
				InputStream is = conn.getInputStream();

				String output = "";
				int let = is.read();
				while(let!=-1)
				{
					output = output + (char)let;
					let = is.read();
				}
				output = output.substring(14,output.length()-3);
				return output;
			}else{ return "Invalid User"; }
		}
		catch(IOException e)
		{
			return "Error";
		}

	}

	//WILL UPDATE A USERS PUBLIC KEY WHEN NEEDED
	public static int updateUserKey(String username) throws IOException, NoSuchAlgorithmException
	{
		if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O)
		{
			String pubkey = Base64.getEncoder().encodeToString(new RSA().getPublic().getEncoded());
			URL apiInterface = new URL(url+":5000/update");
			String[] ids = {"username", "publickey"};
			String[] vals = {username, pubkey};
			jsonObj json = new jsonObj(ids, vals);
			System.out.println(json.toString());
			HttpURLConnection conn = (HttpURLConnection) apiInterface.openConnection();
			conn.setDoOutput(true);
			conn.setDoInput(true);
			conn.setRequestMethod("POST");
			conn.setRequestProperty("Accept", "application/json");
			conn.setRequestProperty("Content-Type", "application/json");
			OutputStream os = conn.getOutputStream();
			os.write(json.toString().getBytes(StandardCharsets.UTF_8));
			os.flush();
			int ret = conn.getResponseCode();
			System.out.println(ret);
			conn.disconnect();
			return ret;
		}
		else
		{
			return -1;
		}


	}

	public static int checkForAccount(String username) throws IOException
	{
		URL apiInterface = new URL(url+":5281/api/check_account");
		String[] ids = {"user", "host"};
		String[] vals = {username, "cipher.com"};
		jsonObj json = new jsonObj(ids, vals);
		HttpURLConnection conn = (HttpURLConnection) apiInterface.openConnection();
		conn.setDoOutput(true);
		conn.setDoInput(true);
		conn.setRequestMethod("POST");
		conn.setRequestProperty("Accept", "application/json");
		conn.setRequestProperty("Content-Type", "application/json");
		OutputStream os = conn.getOutputStream();
		os.write(json.toString().getBytes(StandardCharsets.UTF_8));
		os.flush();
		if(conn.getResponseCode() == 200)
		{
			InputStream is = conn.getInputStream();
			char resp = (char)is.read();
			return Integer.parseInt(String.valueOf(resp));
		}
		else
		{
			conn.disconnect();
			return -1;
		}
	}

	@Override
	protected String doInBackground(String... strings)
	{
		String output;
		switch(strings[0])
		{
			case "checkForAccount":
				try {
					output = String.valueOf(checkForAccount(strings[1]));
				} catch (IOException e) {
					throw new RuntimeException(e);
				}break;
			case "getUserKey": output=getUserKey(strings[1]); break;
			case "registerPublicKey":
				try {
					output = String.valueOf(registerPublicKey(strings[1], strings[2]));
				} catch (IOException e) {
					throw new RuntimeException(e);
				} catch (NoSuchAlgorithmException e) {
					throw new RuntimeException(e);
				}break;
			case "registerEjabberd": output = String.valueOf(registerEjabberd(strings[1], strings[2])); break;
			default: output = "HTTP REQUEST UNSUCCESSFUL";break;
		}
		return output;
	}

	@Override
	protected void onPostExecute(String s)
	{
		super.onPostExecute(s);
	}
}