package com.example.selfdestructim;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import org.jivesoftware.smack.SmackException;
import org.jivesoftware.smack.packet.Presence;
import org.jxmpp.jid.Jid;
import org.jxmpp.jid.impl.JidCreate;
import org.jxmpp.stringprep.XmppStringprepException;
import org.pgpainless.key.selection.keyring.impl.XMPP;

import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Base64;
import javax.crypto.NoSuchPaddingException;

public class AdapterForFriendRequests extends RecyclerView.Adapter<AdapterForFriendRequests.ViewHolder>
{
    private ArrayList<FriendRequestData> friendReqs;
    public AdapterForFriendRequests(ArrayList<FriendRequestData> reqs)
    {
        this.friendReqs=reqs;
    }

    @NonNull
    @Override
    public AdapterForFriendRequests.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.friend_request_item, parent,false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull AdapterForFriendRequests.ViewHolder holder, int position)
    {
        String name = friendReqs.get(position).getName();
        holder.setData(name, position);
    }

    @Override
    public int getItemCount() {
        return friendReqs.size();
    }

    private void removeAt(int position) {
        friendReqs.remove(position);
        notifyItemRemoved(position);
        notifyItemRangeChanged(position, friendReqs.size());
    }

    public class ViewHolder extends RecyclerView.ViewHolder
    {
        private TextView name;
        private ImageButton accept;
        private ImageButton decline;
        public ViewHolder(@NonNull View itemView)
        {
            super(itemView);
            name=itemView.findViewById(R.id.friendsName);
            accept=itemView.findViewById(R.id.acceptButton);
            decline=itemView.findViewById(R.id.declineButton);
        }
        public void setData(String na, int pos)
        {
            name.setText(na);
            accept.setOnClickListener(new View.OnClickListener()
            {
                @Override
                public void onClick(View view)
                {
                    try
                    {

                        Jid tojid = JidCreate.bareFrom(name.getText().toString()+"@cipher.com");
                        Jid fromjid = JidCreate.bareFrom(storage.username+"@cipher.com");
                        XMPPConnection.sendPacket(tojid, fromjid, Presence.Type.subscribed, null);
                        XMPPConnection.sendPacket(tojid, fromjid, Presence.Type.subscribe, null);

                        byte[] aesKey = storage.friendRequests.get(tojid.asBareJid());
                        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O)
                        {
                            String encodedaeskey = Base64.getEncoder().encodeToString(aesKey);
                            storage.writeFriendsAesKeyToFile(false, tojid.toString(), encodedaeskey);
                            storage.friendRequests.remove(tojid.asBareJid());
                        }

                    } catch (XmppStringprepException | InterruptedException |
                             SmackException.NotConnectedException | NoSuchPaddingException |
                             NoSuchAlgorithmException e) {
                        throw new RuntimeException(e);
                    }
                    removeAt(pos);
                }
            });
            decline.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view)
                {
                    try
                    {
                        Jid tojid = JidCreate.bareFrom(name.getText().toString()+"@cipher.com");
                        Jid fromjid = JidCreate.bareFrom(storage.username+"@cipher.com");
                        XMPPConnection.sendPacket(tojid, fromjid, Presence.Type.unsubscribed, null);
                        storage.friendRequests.remove(tojid.asBareJid());

                    } catch (XmppStringprepException | InterruptedException |
                             SmackException.NotConnectedException | NoSuchPaddingException |
                             NoSuchAlgorithmException e) {
                        throw new RuntimeException(e);
                    }
                    removeAt(pos);
                }
            });
        }



    }
}