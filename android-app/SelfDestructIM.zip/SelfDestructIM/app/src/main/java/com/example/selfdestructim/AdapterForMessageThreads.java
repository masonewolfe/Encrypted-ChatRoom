package com.example.selfdestructim;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import org.jivesoftware.smack.packet.Presence;
import java.util.ArrayList;

public class AdapterForMessageThreads extends RecyclerView.Adapter<AdapterForMessageThreads.ViewHolder>
{

    private ArrayList<MessageThreadData> msgThreads;
    public AdapterForMessageThreads(ArrayList<MessageThreadData> msgThreads)
    {
        this.msgThreads=msgThreads;
    }

    @NonNull
    @Override
    public AdapterForMessageThreads.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.message_threads_item, parent,false);
        view.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view)
            {
                TextView username = view.findViewById(R.id.friendsUsername);
                Intent intent = new Intent(parent.getContext(), sendMessage.class);
                intent.putExtra("username", username.getText().toString());
                intent.putExtra("group?", "false");
                parent.getContext().startActivity(intent);
            }
        });
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull AdapterForMessageThreads.ViewHolder holder, int position)
    {
        int image = msgThreads.get(position).getImage();
        String name = msgThreads.get(position).getName();
        holder.setData(image, name);
    }

    @Override
    public int getItemCount() {
        return msgThreads.size();
    }

    public void updateImage(Presence p)
    {
        for(MessageThreadData mtd: msgThreads)
        {
            String from = p.getFrom().asBareJid().toString().replace("@cipher.com","");
            if(mtd.getName().equals(from))
            {
                int pos = msgThreads.indexOf(mtd);
                if(p.getType()==Presence.Type.available)
                {
                    msgThreads.get(pos).setImage(R.drawable.user_online_symbol);
                }
                else if(p.getType()== Presence.Type.unavailable)
                {
                    msgThreads.get(pos).setImage(R.drawable.user_offline_symbol);
                }
                notifyItemChanged(pos);
                break;
            }
        }

    }

    public class ViewHolder extends RecyclerView.ViewHolder
    {
        private ImageView image;
        private TextView name;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            image=itemView.findViewById(R.id.friendsStatus);
            name=itemView.findViewById(R.id.friendsUsername);
        }

        public void setData(int im, String na)
        {
            image.setImageResource(im);
            name.setText(na);
        }
    }

}
