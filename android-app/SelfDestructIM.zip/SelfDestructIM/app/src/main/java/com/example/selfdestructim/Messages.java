package com.example.selfdestructim;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import org.jivesoftware.smack.packet.Presence;
import org.jxmpp.jid.BareJid;
import java.util.ArrayList;

public class Messages extends Fragment
{
    private RecyclerView messageThreads;
    private LinearLayoutManager linLayout;
    private ArrayList<MessageThreadData> items;
    private AdapterForMessageThreads adapter;
    public static Handler h;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState)
    {
        View rootView = inflater.inflate(R.layout.fragment_message, container, false);
        messageThreads = (RecyclerView) rootView.findViewById(R.id.messagesRecyclerView);
        initData();
        initRecyclerView();

        h = new Handler(Looper.getMainLooper())
        {
            @Override
            public void handleMessage(Message msg)
            {
                adapter.updateImage((Presence) msg.obj);
            }
        };

        if(messageThreads.getAdapter().getItemCount()==0)
        {
            messageThreads.setVisibility(View.INVISIBLE);
        }
        return rootView;
    }

    private void initData()
    {
        items = new ArrayList<MessageThreadData>();
        for(BareJid j : storage.friends.keySet())
        {
            Presence p = storage.friends.get(j);
            if(p.getType()==Presence.Type.available)
            {
                items.add(new MessageThreadData(R.drawable.user_online_symbol, j.toString().replaceAll("@cipher.com", "")));
            }
            else if(p.getType()== Presence.Type.unavailable)
            {
                items.add(new MessageThreadData(R.drawable.user_offline_symbol, j.toString().replaceAll("@cipher.com", "")));
            }
        }
    }

    private void initRecyclerView()
    {
        linLayout = new LinearLayoutManager(getContext());
        linLayout.setOrientation(RecyclerView.VERTICAL);
        messageThreads.setLayoutManager(linLayout);
        adapter = new AdapterForMessageThreads(items);
        messageThreads.setAdapter(adapter);
        adapter.notifyDataSetChanged();
    }



}