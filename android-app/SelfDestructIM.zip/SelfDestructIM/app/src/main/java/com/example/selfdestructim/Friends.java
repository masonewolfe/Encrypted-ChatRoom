package com.example.selfdestructim;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import org.jivesoftware.smack.SmackException;
import org.jivesoftware.smack.packet.Presence;
import org.jxmpp.jid.BareJid;
import org.jxmpp.jid.Jid;
import org.jxmpp.jid.impl.JidCreate;
import java.io.IOException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.util.ArrayList;
import java.util.Base64;
import java.util.concurrent.ExecutionException;
import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;
import javax.crypto.spec.IvParameterSpec;

public class Friends extends Fragment
{
    RecyclerView friendRequests;
    LinearLayoutManager linLayout;
    public static ArrayList<FriendRequestData> items = new ArrayList<FriendRequestData>();;
    AdapterForFriendRequests adapter;
    private ImageButton sendFriendReq;
    private EditText friendsName;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_friends, container, false);
        initData();
        initRecyclerView(rootView);
        sendFriendReq = rootView.findViewById(R.id.addFriend);
        friendsName = (EditText) rootView.findViewById(R.id.friendRequestName);

        sendFriendReq.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view)
            {
                String friendName = friendsName.getText().toString();
                if(friendName.trim().equals(""))
                {
                    Toast.makeText(getContext(), "Friends Username Can't Be Empty", Toast.LENGTH_SHORT).show();
                }
                else
                {
                    try
                    {
                        String result = new HttpRequests().execute("checkForAccount", friendName).get();
                        if(result.equals("0"))
                        {
                            String usersPublicKey = new HttpRequests().execute("getUserKey", friendName).get();

                            SecretKey aesKey = AES.generateKey();
                            IvParameterSpec iv = AES.generateIv();


                            int totalLength = aesKey.getEncoded().length+iv.getIV().length;
                            byte[] totalBytes = new byte[totalLength];
                            for(int i=0; i<totalLength; i++)
                            {
                                if(i<aesKey.getEncoded().length)
                                {
                                    totalBytes[i]=aesKey.getEncoded()[i];
                                }
                                else
                                {
                                    int j = i-aesKey.getEncoded().length;
                                    totalBytes[i] = iv.getIV()[j];
                                }
                            }


                            String status = RSA.Encrypt(totalBytes, usersPublicKey);

                            Jid to = JidCreate.bareFrom(friendName + "@cipher.com");
                            Jid from = JidCreate.bareFrom(storage.username + "@cipher.com");
                            XMPPConnection.sendPacket(to, from, Presence.Type.subscribe, status);
                            friendsName.setText("");
                            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O)
                            {
                                String base64Key = Base64.getEncoder().encodeToString(totalBytes);
                                storage.writeFriendsAesKeyToFile(true, to.toString(), base64Key);
                            }
                            Toast.makeText(storage.context, "Request Sent", Toast.LENGTH_SHORT).show();
                        }
                        else
                        {
                            Toast.makeText(storage.context, "User does not exist", Toast.LENGTH_SHORT).show();
                        }
                    } catch (ExecutionException | NoSuchAlgorithmException | IOException |
                             NoSuchPaddingException | SmackException.NotConnectedException |
                             InterruptedException | IllegalBlockSizeException |
                             BadPaddingException | InvalidKeySpecException | InvalidKeyException e) {
                        throw new RuntimeException(e);
                    }
                }


            }
        });

        return rootView;
    }

    private void initData()
    {
        for(BareJid j : storage.friendRequests.keySet())
        {
            items.add(new FriendRequestData(j.toString().replace("@cipher.com", "")));
        }
    }

    private void initRecyclerView(View view)
    {
        friendRequests = (RecyclerView) view.findViewById(R.id.friendRequestsRecyclerView);
        linLayout = new LinearLayoutManager(getContext());
        linLayout.setOrientation(RecyclerView.VERTICAL);
        friendRequests.setLayoutManager(linLayout);
        adapter = new AdapterForFriendRequests(items);
        friendRequests.setAdapter(adapter);
        adapter.notifyDataSetChanged();
    }

}