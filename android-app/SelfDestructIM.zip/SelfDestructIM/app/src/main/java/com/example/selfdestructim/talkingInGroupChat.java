package com.example.selfdestructim;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import org.jivesoftware.smack.MessageListener;
import org.jivesoftware.smack.SmackException;
import org.jivesoftware.smack.XMPPException;
import org.jivesoftware.smack.packet.Message;
import org.jivesoftware.smack.packet.StanzaFactory;
import org.jivesoftware.smackx.muc.MultiUserChat;
import org.jivesoftware.smackx.muc.MultiUserChatException;
import org.jxmpp.jid.Jid;
import org.jxmpp.stringprep.XmppStringprepException;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Base64;
import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;

public class talkingInGroupChat extends AppCompatActivity
{
    private ImageButton sendButton;
    private EditText messageBox;
    public RecyclerView messages;
    public LinearLayoutManager linLayout;
    public ArrayList<Message> items;
    public AdapterForGroupChatMessaging adapter;
    private byte[] totalBytes = null;
    private byte[] aesKey = new byte[16];
    private byte[] iv = new byte[16];
    private Handler vanishMessagesHandler;
    private Runnable vanishMsgsRunnable;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.sending_messages);

        sendButton = (ImageButton) findViewById(R.id.sendButton);
        messageBox = (EditText) findViewById(R.id.editTextMultiLine);
        messages = (RecyclerView) findViewById(R.id.sendingMessagesRecyclerView);
        initRecyclerView();

        String groupName = getIntent().getExtras().getString("groupname");
        String base64aesKey = storage.readGroupKeyFromFile(groupName);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
        {
            totalBytes = Base64.getDecoder().decode(base64aesKey);
        }

        for(int i =0; i<32; i++)
        {
            if(i<16)
            {
                aesKey[i] = totalBytes[i];
            }
            else
            {
                iv[i-16] = totalBytes[i];
            }
        }




        try
        {
            MultiUserChat muc = XMPPConnection.joinChatRoom(groupName, storage.username);

            byte[] finalAes = aesKey;
            byte[] finalIv = iv;
            muc.addMessageListener(new MessageListener()
            {
                @Override
                public void processMessage(Message message)
                {
                    String encMessage = message.getBody();
                    Jid groupChatjid = message.getFrom();
                    String sender = groupChatjid.getResourceOrEmpty().toString();
                    try
                    {
                        if(encMessage!=null)
                        {
                            String decMsg = AES.decrypt(encMessage, finalAes, finalIv);
                            StanzaFactory sf = XMPPConnection.con.getStanzaFactory();
                            Message msg = sf.buildMessageStanza().from(sender).setBody(decMsg).build();
                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    initData(msg);
                                }
                            });
                        }
                    } catch (NoSuchPaddingException | IllegalBlockSizeException |
                             BadPaddingException | InvalidKeyException |
                             InvalidAlgorithmParameterException | NoSuchAlgorithmException |
                             XmppStringprepException e) {
                        throw new RuntimeException(e);
                    }
                }
            });
            sendButton.setOnClickListener(new View.OnClickListener()
            {
                @Override
                public void onClick(View view)
                {
                    try
                    {
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                        {
                            String message = messageBox.getText().toString();
                            String encMessage = AES.encrypt(message, aesKey, iv);
                            muc.sendMessage(encMessage);
                            messageBox.setText("");
                        }
                    } catch (Exception e)
                    {
                        throw new RuntimeException(e);
                    }
                }
            });
        } catch (XmppStringprepException | XMPPException.XMPPErrorException |
                 SmackException.NotConnectedException | SmackException.NoResponseException |
                 InterruptedException | MultiUserChatException.NotAMucServiceException e) {
            throw new RuntimeException(e);
        }
    }
    @Override
    protected void onStart()
    {
        super.onStart();
        vanishMessagesHandler = new Handler();
        vanishMsgsRunnable = new Runnable()
        {
            @Override
            public void run()
            {
                if(!items.isEmpty())
                {
                    adapter.deleteItem(0);
                }
                vanishMessagesHandler.postDelayed(this, 5000);
            }
        };
        vanishMessagesHandler.postDelayed(vanishMsgsRunnable, 5000);
    }

    @Override
    protected void onStop()
    {
        super.onStop();
        vanishMessagesHandler.removeCallbacks(vanishMsgsRunnable);
    }

    public void initData(Message msg)
    {
        adapter.addItem(msg);
    }

    public void initRecyclerView()
    {
        items = new ArrayList<Message>();
        linLayout = new LinearLayoutManager(getApplicationContext());
        linLayout.setOrientation(RecyclerView.VERTICAL);
        messages.setLayoutManager(linLayout);
        adapter = new AdapterForGroupChatMessaging(items);
        messages.setAdapter(adapter);
    }


}