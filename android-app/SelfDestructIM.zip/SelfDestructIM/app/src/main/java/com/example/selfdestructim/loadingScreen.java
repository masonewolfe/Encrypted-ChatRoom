package com.example.selfdestructim;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.PopupWindow;

import org.jivesoftware.smack.android.AndroidSmackInitializer;
import java.security.NoSuchAlgorithmException;
import java.util.concurrent.ExecutionException;
import javax.crypto.NoSuchPaddingException;

public class loadingScreen extends AppCompatActivity
{
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_loading_screen);
        try
        {
            AndroidSmackInitializer.initialize(getApplicationContext());
            storage.Initialize(getApplicationContext());
        } catch (NoSuchPaddingException | NoSuchAlgorithmException e) {
            throw new RuntimeException(e);
        }
        Button login = (Button) findViewById(R.id.login);
        Button signup = (Button) findViewById(R.id.signup);

        SharedPreferences preferences = getSharedPreferences("checkbox", MODE_PRIVATE);
        boolean autoLogin = preferences.getBoolean("remember?", false);
        if(autoLogin)
        {
            String user = preferences.getString("username", "");
            String pass = preferences.getString("password", "");

            new Thread()
            {
                @Override
                public void run()
                {
                    String conStatus = XMPPConnection.setConnection(user, pass);
                    if(conStatus.equals("Success"))
                    {
                        storage.privKeyEncoded = storage.readPrivKeyFromFile();
                        storage.username = user;
                        Intent intent = new Intent(loadingScreen.this, NewUserHome.class);
                        startActivity(intent);
                    }
                    else
                    {
                        throw new RuntimeException("AUTOLOGIN FAILED");
                    }
                }

            }.start();
        }

        login.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {

                Intent intent = new Intent(loadingScreen.this, loginAttempt.class);
                startActivity(intent);
            }
        });

        signup.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                Intent intent = new Intent(loadingScreen.this, registerUser.class);
                startActivity(intent);
            }
        });
    }
}
