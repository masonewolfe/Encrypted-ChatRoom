package com.example.selfdestructim;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;

public class AdapterForMessaging extends RecyclerView.Adapter<AdapterForMessaging.ViewHolder>
{

    private ArrayList<MessageData> messages;
    public AdapterForMessaging(ArrayList<MessageData> messages)
    {
        this.messages=messages;
    }

    @NonNull
    @Override
    public AdapterForMessaging.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType)
    {
        View view;
        if(viewType==0)
        {
            view = LayoutInflater.from(parent.getContext()).inflate(R.layout.message_item2, parent,false);
        }
        else
        {
            view = LayoutInflater.from(parent.getContext()).inflate(R.layout.message_item, parent,false);
        }

        return new ViewHolder(view);
    }



    @Override
    public int getItemViewType(int position)
    {
        return messages.get(position).getViewType();
    }

    public void addItem(MessageData msg)
    {
        messages.add(msg);
        notifyItemInserted(messages.size()-1);
    }

    public void deleteItem(int position)
    {
        if(position>=0 && position< messages.size())
        {
            messages.remove(position);
            notifyItemRemoved(position);
        }
    }


    @Override
    public void onBindViewHolder(@NonNull AdapterForMessaging.ViewHolder holder, int position)
    {
        MessageData msg = messages.get(position);
        String message = msg.getMessage();
        String time = msg.getTime();
        holder.setData(message, time);
    }

    @Override
    public int getItemCount()
    {
        return messages.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder
    {

        private TextView msg;
        private String time;
        public ViewHolder(@NonNull View itemView)
        {
            super(itemView);
            msg=itemView.findViewById(R.id.messageBeingSent);
        }

        public void setData(String message, String time)
        {
            this.msg.setText(message);
            this.time = time;
        }
    }

}