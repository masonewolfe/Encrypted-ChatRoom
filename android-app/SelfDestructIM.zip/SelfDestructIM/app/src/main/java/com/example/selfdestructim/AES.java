package com.example.selfdestructim;
import android.os.Build;
import javax.crypto.*;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.Base64;

public class AES
{

    public static SecretKey generateKey()
    {
        try
        {
            KeyGenerator keyGenerator = KeyGenerator.getInstance("AES");
            keyGenerator.init(128);
            SecretKey key = keyGenerator.generateKey();
            return key;
        }
        catch (NoSuchAlgorithmException e)
        {
            return null;
        }
    }

    public static IvParameterSpec generateIv()
    {
        byte[] iv = new byte[16];
        new SecureRandom().nextBytes(iv);
        return new IvParameterSpec(iv);
    }

    public static String encrypt(String input, byte[] key, byte[] iv) throws NoSuchPaddingException, NoSuchAlgorithmException,
            InvalidAlgorithmParameterException, InvalidKeyException,
            BadPaddingException, IllegalBlockSizeException
    {
        Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
        SecretKey newKey = new SecretKeySpec(key, "AES/CBC/PKCS5Padding");
        IvParameterSpec newIv = new IvParameterSpec(iv);
        cipher.init(Cipher.ENCRYPT_MODE, newKey, newIv);
        byte[] cipherText = cipher.doFinal(input.getBytes());
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
        {
            return Base64.getEncoder().encodeToString(cipherText);
        }else
        {
            throw new RuntimeException("AES ENCRYPTION FAIL");
        }
    }

    public static String decrypt(String cipherText, byte[] key, byte[] iv) throws NoSuchPaddingException, NoSuchAlgorithmException,
            InvalidAlgorithmParameterException, InvalidKeyException,
            BadPaddingException, IllegalBlockSizeException {

        Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
        SecretKey newKey = new SecretKeySpec(key, "AES/CBC/PKCS5Padding");
        IvParameterSpec newIv = new IvParameterSpec(iv);

        cipher.init(Cipher.DECRYPT_MODE, newKey, newIv);

        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O)
        {
            byte[] plainText = cipher.doFinal(Base64.getDecoder().decode(cipherText));
            return new String(plainText);
        }
        else
        {
            throw new RuntimeException("AES DECRYPTION FAILURE");
        }

    }

}