package com.example.selfdestructim;

import androidx.annotation.Nullable;

import org.jxmpp.jid.BareJid;

public class MessageData
{
    private String time;
    private String message;
    private int viewType;
    private BareJid from;

    public MessageData(int view, String message, String time, @Nullable BareJid from)
    {
        this.message = message;
        this.time = time;
        this.viewType = view;
        this.from = from;
    }

    public BareJid getFrom() {
        return from;
    }
    public String getTime() {
        return time;
    }
    public int getViewType(){ return viewType; }
    public String getMessage() {
        return message;
    }


}
