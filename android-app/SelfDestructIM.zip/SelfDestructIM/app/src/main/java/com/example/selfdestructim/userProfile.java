package com.example.selfdestructim;
import static android.content.Context.MODE_PRIVATE;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import java.io.FileNotFoundException;

public class userProfile extends Fragment
{
    private Button logoutBtn;
    private Button wipeFriendsKeys;
    private Button wipeGroupKeys;
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState)
    {
        View rootView = inflater.inflate(R.layout.profile_customization, container, false);

        wipeFriendsKeys = rootView.findViewById(R.id.wipeKeys);
        wipeGroupKeys = rootView.findViewById(R.id.wipeGroupChatKeys);

        wipeFriendsKeys.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view)
            {
                try {
                    storage.clearFile(storage.context.openFileOutput(storage.username+"friends.txt", MODE_PRIVATE));
                } catch (FileNotFoundException e) {
                    throw new RuntimeException(e);
                }
            }
        });

        wipeGroupKeys.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    storage.clearFile(storage.context.openFileOutput(storage.username+"groups.txt", MODE_PRIVATE));
                } catch (FileNotFoundException e) {
                    throw new RuntimeException(e);
                }
            }
        });
        logoutBtn = rootView.findViewById(R.id.logoutBtn);
        logoutBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view)
            {
                XMPPConnection.endConnection();
                SharedPreferences preferences = storage.context.getSharedPreferences("checkbox", MODE_PRIVATE);
                SharedPreferences.Editor editor = preferences.edit();
                editor.putBoolean("remember?", false);
                editor.putString("username", "");
                editor.putString("password", "");
                editor.apply();
                storage.wipe();
                Intent intent = new Intent(getActivity(), loadingScreen.class);
                startActivity(intent);
            }
        });
        return rootView;
    }
}
