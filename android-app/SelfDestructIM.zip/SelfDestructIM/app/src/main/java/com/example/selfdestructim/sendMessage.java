package com.example.selfdestructim;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;

import org.jivesoftware.smack.MessageListener;
import org.jivesoftware.smack.SmackException;
import org.jivesoftware.smack.XMPPException;
import org.jivesoftware.smack.chat2.Chat;
import org.jivesoftware.smackx.muc.MultiUserChat;
import org.jivesoftware.smackx.muc.MultiUserChatException;
import org.jxmpp.jid.BareJid;
import org.jxmpp.jid.impl.JidCreate;
import org.jxmpp.stringprep.XmppStringprepException;

import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Calendar;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;

public class sendMessage extends AppCompatActivity
{
    private ImageButton sendButton;
    private EditText multiLineMessage;
    public RecyclerView messages;
    public LinearLayoutManager linLayout;
    public ArrayList<MessageData> items;
    public AdapterForMessaging adapter;
    private BareJid recipientJid;
    public static Handler mHandler;
    private byte[] totalBytes = null;
    private byte[] aesKey = new byte[16];
    private byte[] iv = new byte[16];
    public Chat chat;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.sending_messages);
        sendButton = (ImageButton) findViewById(R.id.sendButton);
        multiLineMessage = (EditText) findViewById(R.id.editTextMultiLine);
        messages = (RecyclerView) findViewById(R.id.sendingMessagesRecyclerView);
        initRecyclerView();
        String sendTo = getIntent().getExtras().getString("username");
        String isGroup = getIntent().getExtras().getString("group?");

        if(isGroup.equals("false"))
        {
            try
            {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                {
                    recipientJid = JidCreate.bareFrom(sendTo+"@cipher.com");
                    mHandler = new Handler(Looper.getMainLooper())
                    {
                        @Override
                        public void handleMessage(Message msg)
                        {
                            addNewMessage(recipientJid);
                        }
                    };

                    String base64Key = storage.readFriendKeyFromFile(recipientJid);
                    totalBytes = Base64.getDecoder().decode(base64Key);

                    for(int i =0; i<32; i++)
                    {
                        if(i<16)
                        {
                            aesKey[i] = totalBytes[i];
                        }
                        else
                        {
                            iv[i-16] = totalBytes[i];
                        }
                    }

                    chat = XMPPConnection.chatManager.chatWith(recipientJid.asEntityBareJidIfPossible());
                    addUnreadMessages(recipientJid);
                }

            } catch (Exception e)
            {
                throw new RuntimeException(e);
            }

            sendButton.setOnClickListener(new View.OnClickListener()
            {
                @Override
                public void onClick(View view)
                {
                    try
                    {
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                        {
                            String message = multiLineMessage.getText().toString();
                            String encMessage = AES.encrypt(message, aesKey, iv);
                            chat.send(encMessage);
                            initData(new MessageData(0,message, Calendar.getInstance().getTime().toString(), null));
                            multiLineMessage.setText("");
                        }
                    } catch (Exception e)
                    {
                        throw new RuntimeException(e);
                    }
                }
            });
        }
        else if(isGroup.equals("true"))
        {
            addUnreadGroupMessages(sendTo);
            String base64aesKey = storage.readGroupKeyFromFile(sendTo);
            storage.readFile(storage.username+"groups.txt");
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            {
                totalBytes = Base64.getDecoder().decode(base64aesKey);
            }

            for(int i =0; i<32; i++)
            {
                if(i<16)
                {
                    aesKey[i] = totalBytes[i];
                }
                else
                {
                    iv[i-16] = totalBytes[i];
                }
            }

            mHandler = new Handler(Looper.getMainLooper())
            {
                @Override
                public void handleMessage(Message msg)
                {
                    for(GroupChatData cg : storage.groupChats.keySet())
                    {
                        if(cg.getGroupChatName().equals(sendTo))
                        {
                            int i = storage.groupChats.get(cg).size();
                            MessageData m = storage.groupChats.get(cg).get(i-1);
                            initData(m);
                        }
                    }
                }
            };

            try
            {
                MultiUserChat muc = XMPPConnection.joinChatRoom(sendTo, storage.username);
                String base64key = storage.readGroupKeyFromFile(sendTo);
                if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O)
                {
                    totalBytes = Base64.getDecoder().decode(base64key);
                    aesKey = new byte[16];
                    iv = new byte[16];
                    for(int i=0; i<totalBytes.length; i++)
                    {
                        if(i<16)
                        {
                            aesKey[i] = totalBytes[i];
                        }
                        else
                        {
                            iv[i-16] = totalBytes[i];
                        }
                    }
                }

                byte[] finalAes = aesKey;
                byte[] finalIv = iv;

                muc.addMessageListener(new MessageListener()
                {
                    @Override
                    public void processMessage(org.jivesoftware.smack.packet.Message message)
                    {
                        String encMessage = message.getBody();
                        try
                        {
                            if(encMessage!=null)
                            {
                                String decMsg = AES.decrypt(encMessage, finalAes, finalIv);
                                for(GroupChatData gc: storage.groupChats.keySet())
                                {
                                    if(gc.getGroupChatName().equals(sendTo))
                                    {
                                        initData(new MessageData(1, decMsg, Calendar.getInstance().getTime().toString(), message.getFrom().asBareJid()));
                                        break;
                                    }
                                }
                            }

                        } catch (NoSuchPaddingException | IllegalBlockSizeException | BadPaddingException |
                                 InvalidKeyException | InvalidAlgorithmParameterException |
                                 NoSuchAlgorithmException e) {
                            throw new RuntimeException(e);
                        }
                    }
                });
                sendButton.setOnClickListener(new View.OnClickListener()
                {
                    @Override
                    public void onClick(View view)
                    {
                        try
                        {
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                            {
                                String message = storage.username+":  "+multiLineMessage.getText().toString();
                                String encMessage = AES.encrypt(message, aesKey, iv);
                                muc.sendMessage(encMessage);
                                initData(new MessageData(0,message, Calendar.getInstance().getTime().toString(), null));
                                multiLineMessage.setText("");
                            }
                        } catch (Exception e)
                        {
                            throw new RuntimeException(e);
                        }
                    }
                });



            } catch (XmppStringprepException | XMPPException.XMPPErrorException |
                     SmackException.NotConnectedException | SmackException.NoResponseException |
                     InterruptedException | MultiUserChatException.NotAMucServiceException e) {
                throw new RuntimeException(e);
            }


        }



    }

    public void addUnreadMessages(BareJid jid)
    {
        for(MessageData m : storage.jidsToMessages.get(jid))
        {
            initData(m);
        }
    }

    public void addUnreadGroupMessages(String roomName)
    {
        for(GroupChatData d : storage.groupChats.keySet())
        {
            if(d.getGroupChatName().equals(roomName))
            {
                for(MessageData m: storage.groupChats.get(d))
                {
                    initData(m);
                }
            }
        }
    }

    public void addNewMessage(BareJid jid)
    {
        int s = storage.jidsToMessages.get(jid).size();
        MessageData m = storage.jidsToMessages.get(jid).get(s-1);
        initData(m);
    }


    public void initData(MessageData msg)
    {
        adapter.addItem(msg);
    }

    public void initRecyclerView()
    {
        items = new ArrayList<MessageData>();
        linLayout = new LinearLayoutManager(getApplicationContext());
        linLayout.setOrientation(RecyclerView.VERTICAL);
        messages.setLayoutManager(linLayout);
        adapter = new AdapterForMessaging(items);
        messages.setAdapter(adapter);
    }


}
