package com.example.selfdestructim;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import org.jivesoftware.smack.chat2.Chat;
import org.jxmpp.jid.BareJid;
import org.jxmpp.jid.impl.JidCreate;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Calendar;

public class sendMessage extends AppCompatActivity
{
    private ImageButton sendButton;
    private EditText multiLineMessage;
    public RecyclerView messages;
    public LinearLayoutManager linLayout;
    public ArrayList<MessageData> items;
    public static AdapterForMessaging adapter;
    private BareJid recipientJid;
    public static Handler newMessageHandler;
    private Handler vanishMessagesHandler;
    private Runnable vanishMsgsRunnable;
    private byte[] totalBytes = null;
    private byte[] aesKey = new byte[16];
    private byte[] iv = new byte[16];
    public Chat chat;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.sending_messages);
        sendButton = (ImageButton) findViewById(R.id.sendButton);
        multiLineMessage = (EditText) findViewById(R.id.editTextMultiLine);
        messages = (RecyclerView) findViewById(R.id.sendingMessagesRecyclerView);
        String sendTo = getIntent().getExtras().getString("username");

        try
        {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            {
                recipientJid = JidCreate.bareFrom(sendTo+"@cipher.com");
                initRecyclerView();
                String base64Key = storage.readFriendKeyFromFile(recipientJid);
                totalBytes = Base64.getDecoder().decode(base64Key);

                for(int i =0; i<32; i++)
                {
                    if(i<16)
                    {
                        aesKey[i] = totalBytes[i];
                    }
                    else
                    {
                        iv[i-16] = totalBytes[i];
                    }
                }

                chat = XMPPConnection.chatManager.chatWith(recipientJid.asEntityBareJidIfPossible());
            }

        } catch (Exception e)
        {
            throw new RuntimeException(e);
        }

        sendButton.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                try
                {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                    {
                        String message = multiLineMessage.getText().toString();
                        String encMessage = AES.encrypt(message, aesKey, iv);
                        chat.send(encMessage);
                        multiLineMessage.setText("");
                        initData(new MessageData(0,message, Calendar.getInstance().getTime().toString(), null));
                    }
                } catch (Exception e)
                {
                    throw new RuntimeException(e);
                }
            }
        });

    }

    @Override
    protected void onStart()
    {
        super.onStart();
        newMessageHandler = new Handler(Looper.getMainLooper())
        {
            @Override
            public void handleMessage(Message msg)
            {
                adapter.notifyItemInserted(adapter.getItemCount()-1);
            }
        };
        vanishMessagesHandler = new Handler();
        vanishMsgsRunnable = new Runnable()
        {
            @Override
            public void run()
            {
                if(!items.isEmpty())
                {
                    adapter.deleteItem(0);
                }
                vanishMessagesHandler.postDelayed(this, 5000);
            }
        };
        vanishMessagesHandler.postDelayed(vanishMsgsRunnable, 5000);
    }

    @Override
    protected void onStop() {
        super.onStop();
        vanishMessagesHandler.removeCallbacks(vanishMsgsRunnable);
    }

    public void initData(MessageData msg)
    {
        adapter.addItem(msg);
    }

    public void initRecyclerView()
    {
        items = storage.jidsToMessages.get(recipientJid);
        linLayout = new LinearLayoutManager(getApplicationContext());
        linLayout.setOrientation(RecyclerView.VERTICAL);
        messages.setLayoutManager(linLayout);
        adapter = new AdapterForMessaging(items);
        messages.setAdapter(adapter);
    }


}
