package com.example.selfdestructim;

public class GroupChatData
{
    private boolean pending;
    private String groupChatName;
    private String invitorsName;
    private String key;


    public GroupChatData(boolean pend, String name, String inv, String k)
    {
        this.pending=pend;
        this.groupChatName = name;
        this.invitorsName = inv;
        this.key=k;
    }

    public boolean getPending() {return pending;}
    public String getGroupChatName() {
        return groupChatName;
    }
    public String getInvitorsName() {
        return invitorsName;
    }
    public String getKey() {
        return key;
    }
}
