package com.example.selfdestructim;
import javax.crypto.*;
import java.io.UnsupportedEncodingException;
import java.security.*;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import java.util.Base64;

public class RSA {

    private PrivateKey Private;
    private PublicKey Public;

    public RSA() throws NoSuchAlgorithmException
    {
        KeyPairGenerator Generator = KeyPairGenerator.getInstance("RSA");
        Generator.initialize(1024);
        KeyPair Pair = Generator.generateKeyPair();
        Private = Pair.getPrivate();
        Public = Pair.getPublic();
    }


    public static String Encrypt(byte[] arr, String base64publicKey) throws NoSuchPaddingException, NoSuchAlgorithmException, InvalidKeyException, IllegalBlockSizeException, BadPaddingException, InvalidKeySpecException
    {
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O)
        {
            byte[] pubKeyBytes = Base64.getDecoder().decode(base64publicKey); //your friends public key needs to be decoded into its original byte array
            X509EncodedKeySpec pubKeySpec = new X509EncodedKeySpec(pubKeyBytes);
            KeyFactory keyFactory = KeyFactory.getInstance("RSA");
            PublicKey pubkey = keyFactory.generatePublic(pubKeySpec); //Generate a PublicKey object from the byte array


            Cipher Encryption = Cipher.getInstance("RSA/ECB/PKCS1Padding"); //Encryption method
            Encryption.init(Cipher.ENCRYPT_MODE, pubkey); //pass in PublicKey we created from above
            byte[] encryptedBytes = Encryption.doFinal(arr); //Wala!
            return Base64.getEncoder().encodeToString(encryptedBytes);

        }
        else
        {
            throw new RuntimeException("ANDROID BUILD INVALID!");
        }
    }


    public static byte[] Decrypt(String encryptedMsg, String base64privateKey) throws NoSuchPaddingException, NoSuchAlgorithmException, InvalidKeyException, IllegalBlockSizeException, BadPaddingException, UnsupportedEncodingException, InvalidKeySpecException
    {
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O)
        {
            byte[] privKeyBytes = Base64.getDecoder().decode(base64privateKey);
            PKCS8EncodedKeySpec keySpec = new PKCS8EncodedKeySpec(privKeyBytes);
            KeyFactory kf = KeyFactory.getInstance("RSA");
            PrivateKey privKey = kf.generatePrivate(keySpec);



            byte[] decodedBytes = Base64.getDecoder().decode(encryptedMsg);
            Cipher Decryption = Cipher.getInstance("RSA/ECB/PKCS1Padding");
            Decryption.init(Cipher.DECRYPT_MODE, privKey);
            byte[] arr = Decryption.doFinal(decodedBytes);
            return arr;
        }
        else
        {
            throw new RuntimeException("ANDROID BUILD INVALID!");
        }
    }




    public PrivateKey getPrivate() {
        return Private;
    }


    public PublicKey getPublic() {
        return Public;
    }

}