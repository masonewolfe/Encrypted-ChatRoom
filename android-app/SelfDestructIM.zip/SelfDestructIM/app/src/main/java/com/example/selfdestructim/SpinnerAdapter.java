package com.example.selfdestructim;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import org.jxmpp.jid.BareJid;
import java.util.ArrayList;
import java.util.HashSet;

public class SpinnerAdapter extends ArrayAdapter<BareJid>
{

    private ArrayList<BareJid> friends;
    private HashSet<BareJid> friendsSelected;

    public SpinnerAdapter(Context context, ArrayList<BareJid> friends)
    {
        super(context, 0, friends);
        this.friends = friends;
        this.friendsSelected = new HashSet<BareJid>();
    }

    @NonNull
    @Override
    public View getView(int position, View convertView, ViewGroup parent)
    {
        if (convertView == null)
        {
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.spinner_default_view, parent, false);
        }
        return convertView;
    }

    @Override
    public View getDropDownView(int position, @Nullable
    View convertView, @NonNull ViewGroup parent)
    {
        if (convertView == null)
        {
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.spinner_drop_item, parent, false);
        }

        TextView tv = convertView.findViewById(R.id.spinnerFriendsName);
        tv.setText(friends.get(position).toString());

        CheckBox cb = convertView.findViewById(R.id.spinnerCheckBox);
        cb.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b)
            {
                if(cb.isChecked())
                {
                    friendsSelected.add(friends.get(position));
                }
                else
                {
                    friendsSelected.remove(friends.get(position));
                }
            }
        });
        return convertView;
    }

    public ArrayList<BareJid> getInvitees()
    {
        return new ArrayList<BareJid>(friendsSelected);
    }

}
