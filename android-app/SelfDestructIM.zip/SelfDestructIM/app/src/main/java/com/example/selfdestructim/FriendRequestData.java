package com.example.selfdestructim;

public class FriendRequestData
{
    private String name;

    public FriendRequestData(String name)
    {
        this.name = name;
    }

    public String getName(){return name;}
}