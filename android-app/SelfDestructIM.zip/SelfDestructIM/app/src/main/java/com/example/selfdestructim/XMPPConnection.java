package com.example.selfdestructim;
import androidx.annotation.Nullable;
import org.jivesoftware.smack.AbstractXMPPConnection;
import org.jivesoftware.smack.ConnectionConfiguration;
import org.jivesoftware.smack.SmackException;
import org.jivesoftware.smack.XMPPException;
import org.jivesoftware.smack.chat2.Chat;
import org.jivesoftware.smack.chat2.ChatManager;
import org.jivesoftware.smack.chat2.IncomingChatMessageListener;
import org.jivesoftware.smack.packet.Message;
import org.jivesoftware.smack.packet.Presence;
import org.jivesoftware.smack.packet.PresenceBuilder;
import org.jivesoftware.smack.packet.StanzaFactory;
import org.jivesoftware.smack.roster.Roster;
import org.jivesoftware.smack.roster.RosterEntry;
import org.jivesoftware.smack.roster.RosterListener;
import org.jivesoftware.smack.roster.SubscribeListener;
import org.jivesoftware.smack.tcp.XMPPTCPConnection;
import org.jivesoftware.smack.tcp.XMPPTCPConnectionConfiguration;
import org.jivesoftware.smackx.muc.InvitationListener;
import org.jivesoftware.smackx.muc.MultiUserChat;
import org.jivesoftware.smackx.muc.MultiUserChatException;
import org.jivesoftware.smackx.muc.MultiUserChatManager;
import org.jivesoftware.smackx.muc.packet.MUCUser;
import org.jxmpp.jid.BareJid;
import org.jxmpp.jid.DomainBareJid;
import org.jxmpp.jid.EntityBareJid;
import org.jxmpp.jid.EntityJid;
import org.jxmpp.jid.Jid;
import org.jxmpp.jid.impl.JidCreate;
import org.jxmpp.jid.parts.Resourcepart;
import org.jxmpp.stringprep.XmppStringprepException;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.InetAddress;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Calendar;
import java.util.Collection;
import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.net.ssl.HostnameVerifier;
public class XMPPConnection
{
    public static AbstractXMPPConnection con;
    public static ChatManager chatManager;
    public static MultiUserChatManager mucMan;
    public static Roster roster;

    public static String setConnection(String username, String password)
    {
        try
        {
            InetAddress addr = InetAddress.getByName("3.91.204.251");
            HostnameVerifier verifier = (hostname, session) -> false;
            DomainBareJid serviceName = JidCreate.domainBareFrom("cipher.com");
            XMPPTCPConnectionConfiguration config = XMPPTCPConnectionConfiguration.builder()
                    .setUsernameAndPassword(username, password)
                    .setPort(5222)
                    .setSecurityMode(ConnectionConfiguration.SecurityMode.disabled)
                    .setXmppDomain(serviceName)
                    .setHostnameVerifier(verifier)
                    .setHostAddress(addr)
                    .setSendPresence(true)
                    .build();
            con = new XMPPTCPConnection(config);
            con.connect();
            con.login();
            getFriends();
            recieveMessages();
            mucMan = MultiUserChatManager.getInstanceFor(con);
            listenForChatRoomInvites(username);
            return "Success";
        } catch (SmackException | IOException | NoSuchAlgorithmException | XMPPException |
                 InterruptedException e)
        {
            return "Error";
        }

    }

    public static void endConnection()
    {
        con.disconnect();
    }

    public static void sendPacket(Jid to, Jid from, Presence.Type type, @Nullable String base64aeskey) throws SmackException.NotConnectedException, InterruptedException, NoSuchPaddingException, NoSuchAlgorithmException
    {
        StanzaFactory sf = con.getStanzaFactory();
        PresenceBuilder presence = sf.buildPresenceStanza();
        presence.to(to);
        presence.from(from);
        presence.ofType(type);
        if(base64aeskey!=null)
        {
            presence.setStatus(base64aeskey);
        }
        con.sendStanza(presence.build());
    }

    public static void recieveMessages() throws NoSuchAlgorithmException
    {
        chatManager = ChatManager.getInstanceFor(con);
        chatManager.addIncomingListener(new IncomingChatMessageListener() {
            @Override
            public void newIncomingMessage(EntityBareJid from, Message message, Chat chat)
            {
                try
                {
                    if(storage.friends.get(from.asBareJid())!=null)
                    {

                        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O)
                        {
                            String base64key = storage.readFriendKeyFromFile(from);
                            byte[] total = Base64.getDecoder().decode(base64key);
                            byte[] aesKey = new byte[16];
                            byte[] iv = new byte[16];
                            for(int i=0; i<32; i++)
                            {
                                if(i<16)
                                {
                                    aesKey[i] = total[i];
                                }
                                else
                                {
                                    iv[i-16] = total[i];
                                }
                            }
                            String decMsg = AES.decrypt(message.getBody(), aesKey, iv);
                            System.out.println(decMsg);
                            storage.jidsToMessages.get(from).add(new MessageData(1,decMsg, Calendar.getInstance().getTime().toString(), from.asBareJid()));
                            if(sendMessage.newMessageHandler!=null)
                            {
                                sendMessage.newMessageHandler.sendMessage(android.os.Message.obtain());
                            }
                        }

                    }

                } catch (Exception e) {
                    throw new RuntimeException(e);
                }
            }
        });
    }

    public static void createChatRoom(String nameOfRoom, String yourNickName, @Nullable ArrayList<BareJid> invitees, @Nullable ArrayList<String> inviteKeys) throws XmppStringprepException, XMPPException.XMPPErrorException, SmackException.NotConnectedException, SmackException.NoResponseException, InterruptedException, MultiUserChatException.NotAMucServiceException
    {
        MultiUserChat myroom = mucMan.getMultiUserChat(JidCreate.entityBareFrom(nameOfRoom+"@conference.cipher.com"));
        myroom.join(Resourcepart.fromOrNull(yourNickName));
        for(int i =0; i<invitees.size(); i++)
        {
            myroom.invite((EntityBareJid) invitees.get(i), inviteKeys.get(i));
        }
    }

    public static MultiUserChat joinChatRoom(String roomJid, String nickname) throws XmppStringprepException, XMPPException.XMPPErrorException, SmackException.NotConnectedException, SmackException.NoResponseException, InterruptedException, MultiUserChatException.NotAMucServiceException
    {
        MultiUserChat someRoom = mucMan.getMultiUserChat(JidCreate.entityBareFrom(roomJid));
        someRoom.join(Resourcepart.fromOrNull(nickname));
        return someRoom;
    }
    private static void listenForChatRoomInvites(String username)
    {
        storage.groupChats = storage.getGroupChatsFromFile(username+"groups.txt");
        mucMan.addInvitationListener(new InvitationListener()
        {
            @Override
            public void invitationReceived(org.jivesoftware.smack.XMPPConnection conn, MultiUserChat room, EntityJid inviter, String key, String password, Message message, MUCUser.Invite invitation)
            {
                System.out.println("Invitation Received!, From: " + inviter.toString() + " to join " + room.toString());
                storage.groupChats.add(new GroupChatData(true, room.getRoom().asEntityBareJidString(), inviter.asEntityBareJidString(), key));
                storage.writeGroupChatInfoToFile(true, room.getRoom().asEntityBareJidString(), inviter.asEntityBareJidString(), key);
            }
        });
    }



    public static void getFriends() throws SmackException.NotConnectedException, SmackException.NotLoggedInException, InterruptedException, XMPPException.XMPPErrorException, SmackException.NoResponseException
    {
        System.out.println("PULLING FRIENDS LIST");
        roster = Roster.getInstanceFor(con);

        for(RosterEntry R: roster.getEntries())
        {
            if(!R.isSubscriptionPending() && R.getType().toString().equals("none"))
            {
                roster.removeEntry(R);
            }
            else if(!R.getType().toString().equals("none"))
            {
                Presence p = roster.getPresence(R.getJid());
                System.out.println(R.toString()+ " is your friend and is " + p.getType().toString());
                storage.friends.put(R.getJid(), p);
                storage.jidsToMessages.put(R.getJid(), new ArrayList<MessageData>());
            }
        }

        roster.setSubscriptionMode(Roster.SubscriptionMode.manual);

        roster.addSubscribeListener(new SubscribeListener()
        {
            @Override
            public SubscribeAnswer processSubscribe(Jid from, Presence subscribeRequest)
            {

                try
                {
                    String status = subscribeRequest.getStatus();
                    System.out.println(from.toString()+" : "+status);
                    if(status!=null)
                    {
                        byte[] total = RSA.Decrypt(status, storage.privKeyEncoded);
                        storage.friendRequests.put(from.asBareJid(), total);
                    }
                    else
                    {
                        sendPacket(from, JidCreate.from(storage.username+"@cipher.com"), Presence.Type.subscribed, null);
                    }


                }catch (NoSuchPaddingException | NoSuchAlgorithmException | InvalidKeyException |
                        IllegalBlockSizeException | BadPaddingException |
                        UnsupportedEncodingException | InvalidKeySpecException |
                        InterruptedException | XmppStringprepException |
                        SmackException.NotConnectedException e)
                {
                    throw new RuntimeException(e);
                }
                return null;
            }
        });

        roster.addRosterListener(new RosterListener()
        {
            @Override
            public void entriesAdded(Collection<Jid> addresses)
            {
                for(Jid j : addresses)
                {
                    RosterEntry re = roster.getEntry(j.asBareJid());
                    if(!re.isSubscriptionPending() && !re.getType().toString().equals("none"))
                    {
                        storage.friends.put(re.getJid(), roster.getPresence(re.getJid()));
                        storage.jidsToMessages.put(re.getJid(), new ArrayList<MessageData>());
                    }
                }
            }

            @Override
            public void entriesUpdated(Collection<Jid> addresses)
            {
                System.out.println("an entry was updated in your roster");
                for(Jid j : addresses)
                {
                    RosterEntry re = roster.getEntry(j.asBareJid());
                    if(!re.isSubscriptionPending() && !re.getType().toString().equals("none"))
                    {
                        storage.friends.put(re.getJid(), roster.getPresence(re.getJid()));
                        storage.jidsToMessages.put(re.getJid(), new ArrayList<MessageData>());
                    }
                }
            }

            @Override
            public void entriesDeleted(Collection<Jid> addresses)
            {
                System.out.println("An entry has been removed from your roster");
            }

            @Override
            public void presenceChanged(Presence presence)
            {
                System.out.println(presence.getFrom().toString()+": PRESENCE HAS CHANGED");
                storage.friends.put(presence.getFrom().asBareJid(), presence);
                if(Messages.h!=null)
                {
                    android.os.Message m = android.os.Message.obtain();
                    m.obj = presence;
                    Messages.h.sendMessage(m);
                }
            }
        });
    }

}


