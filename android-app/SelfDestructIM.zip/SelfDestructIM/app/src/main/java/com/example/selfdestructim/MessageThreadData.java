package com.example.selfdestructim;

public class MessageThreadData
{
    private int image;
    private String name;


    public MessageThreadData(int image, String name)
    {
        this.image = image;
        this.name = name;
    }

    public void setImage(int k)
    {
        this.image = k;
    }

    public int getImage() {return image;}
    public String getName() {
        return name;
    }
}
