package com.example.selfdestructim;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Looper;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;
import java.util.concurrent.ExecutionException;

public class registerUser extends AppCompatActivity
{
    private EditText username;
    private EditText password;
    private EditText email;
    private Button submit;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register_user);

        username = findViewById(R.id.editTextUsername);
        password = findViewById(R.id.editTextPassword);
        email = findViewById(R.id.editTextEmail);
        submit = findViewById(R.id.regButton);

        submit.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                boolean validEmail = checkForValidEmail(email.getText().toString());
                boolean validPassword = checkForValidPassword(password.getText().toString());
                boolean validUsername = checkForValidUsername(username.getText().toString());

                if(validEmail&&validPassword&&validUsername)
                {
                    try
                    {
                        String responseCode = new HttpRequests().execute("registerEjabberd", username.getText().toString(), password.getText().toString() ).get();
                        if(responseCode.equals("200"))
                        {
                            responseCode =  new HttpRequests().execute("registerPublicKey", username.getText().toString(), email.getText().toString()).get();
                            if(responseCode.equals("200"))
                            {
                                Toast.makeText(getApplicationContext(), "Registration Successful", Toast.LENGTH_SHORT).show();
                                storage.username = username.getText().toString();
                                storage.writePrivKeyToFile();
                                new Thread()
                                {

                                    @Override
                                    public void run()
                                    {
                                        Looper.prepare();
                                        String conStatus = XMPPConnection.setConnection(username.getText().toString(), password.getText().toString());
                                        if(conStatus.equals("Success"))
                                        {
                                            Toast.makeText(storage.context, "Login Successful", Toast.LENGTH_SHORT).show();
                                            Intent intent = new Intent(registerUser.this, NewUserHome.class);
                                            startActivity(intent);
                                        }
                                        else
                                        {
                                            throw new RuntimeException("CONNECTION COULDN'T BE ESTABLISHED");
                                        }
                                    }
                                }.start();

                            }
                            else
                            {
                                throw new RuntimeException("COULD NOT REGISTER PUBLIC KEY");
                            }
                        }
                        else if(responseCode.equals("409"))
                        {
                            Toast.makeText(getApplicationContext(), "Username is unavailable", Toast.LENGTH_SHORT).show();
                        }
                        else if(responseCode.equals("-1"))
                        {
                            Toast.makeText(getApplicationContext(), "Error connecting to the Server", Toast.LENGTH_SHORT).show();
                        }
                    } catch (ExecutionException | InterruptedException e) {
                        throw new RuntimeException(e);
                    }
                }
                else
                {
                    if(!validUsername)
                    {
                        Toast.makeText(registerUser.this, "Username invalid\nPlease make sure username only contains:\na-z,A-Z,0-9,-,_", Toast.LENGTH_SHORT).show();
                    }
                    if(!validPassword)
                    {
                        Toast.makeText(registerUser.this, "Password invalid\nMust have at least:\n1 capital, 1 lowercase, 1 number, 8 characters", Toast.LENGTH_SHORT).show();
                    }
                    if(!validEmail)
                    {
                        Toast.makeText(registerUser.this, "Email Invalid\nPlease enter valid email", Toast.LENGTH_SHORT).show();
                    }
                }


            }
        });
    }

    private boolean checkForValidEmail(String email)
    {
        boolean hasAt = false;
        boolean hasDomain = false;
        boolean lengthOkay = false;
        if(email.contains("@"))
        {
            hasAt = true;
        }
        if(email.contains(".com") || email.contains(".org") || email.contains(".edu") || email.contains(".net") || email.contains(".gov"))
        {
            hasDomain = true;
        }
        if(email.length()<=40)
        {
            lengthOkay=true;
        }
        return (hasAt&&hasDomain&&lengthOkay);
    }

    private boolean checkForValidUsername(String username)
    {
        boolean isValid = true;
        for(int i=0; i<username.length(); i++)
        {
            int ascii = username.charAt(i);
            if (!((ascii >= 65 && ascii <=90) || (ascii>=97 && ascii <=122) || (ascii >=48 && ascii<=57) || ascii == 45 || ascii == 95))
            {
                isValid = false;
                break;
            }
        }
        return isValid;
    }

    private boolean checkForValidPassword(String password)
    {
        boolean isLong = false;
        boolean hasCap = false;
        boolean hasLow = false;
        boolean hasNum = false;

        if(password.length()>=8)
        {
            isLong = true;
        }else{return false;}

        for(int i =0; i<password.length(); i++)
        {
            int ascii = password.charAt(i);
            if(ascii>=65 && ascii<=90)
            {
                hasCap = true;
            }
            if(ascii>=97 && ascii<=122)
            {
                hasLow = true;
            }
            if(ascii>=48 && ascii<=57)
            {
                hasNum = true;
            }
        }
        return (isLong && hasCap && hasLow && hasNum);
    }



}