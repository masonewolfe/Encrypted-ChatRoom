package com.example.selfdestructim;

public class jsonObj
{
    private String output;
    public jsonObj(String[] IDS, String[] VALS)
    {
        if(IDS.length!=VALS.length)
        {
            throw new RuntimeException("INVALID ARGUMENTS PASSED!");
        }
        else
        {
            output = "{";
            for(int i=0; i<IDS.length; i++)
            {
                String temp;
                if(i!=IDS.length-1)
                {
                    temp = "\n   \"" + IDS[i] + "\" : \"" + VALS[i] + "\",";
                }
                else
                {
                    temp = "\n   \"" + IDS[i] + "\" : \"" + VALS[i] + "\"";
                }
                output = output + temp;
            }
            output = output + "\n}";
        }
    }

    public String toString()
    {
        return output;
    }
    
}
