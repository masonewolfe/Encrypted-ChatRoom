package com.example.selfdestructim;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import org.jivesoftware.smack.packet.Message;
import java.util.ArrayList;

public class AdapterForGroupChatMessaging extends RecyclerView.Adapter<com.example.selfdestructim.AdapterForGroupChatMessaging.ViewHolder>
{
    private ArrayList<Message> groupMessages;

    public AdapterForGroupChatMessaging(ArrayList<Message> messages)
    {
        this.groupMessages=messages;
    }

    @NonNull
    @Override
    public AdapterForGroupChatMessaging.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType)
    {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.groupchat_message_bubble, parent,false);
        return new ViewHolder(view);
    }

    public void addItem(Message msg)
    {
        groupMessages.add(msg);
        notifyItemInserted(groupMessages.size()-1);
    }

    public void deleteItem(int position)
    {
        if(position>=0 && position< groupMessages.size())
        {
            groupMessages.remove(0);
            notifyItemRemoved(0);
        }
    }



    @Override
    public void onBindViewHolder(@NonNull AdapterForGroupChatMessaging.ViewHolder holder, int position)
    {
        Message msg = groupMessages.get(position);
        String body = msg.getBody();
        String from = msg.getFrom().asBareJid().toString().replace("@cipher.com","");
        holder.setData(body, from);
    }

    @Override
    public int getItemCount()
    {
        return groupMessages.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder
    {

        private TextView msg;
        private TextView from;
        public ViewHolder(@NonNull View itemView)
        {
            super(itemView);
            msg=itemView.findViewById(R.id.messageBeingSent);
            from=itemView.findViewById(R.id.userGroupChatNickname);
        }

        public void setData(String message, String from)
        {
            this.msg.setText(message);
            this.from.setText(from);
        }
    }

}