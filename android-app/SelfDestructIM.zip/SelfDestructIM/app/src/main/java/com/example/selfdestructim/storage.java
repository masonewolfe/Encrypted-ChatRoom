package com.example.selfdestructim;
import android.content.Context;
import android.os.Build;
import androidx.appcompat.app.AppCompatActivity;
import org.jivesoftware.smack.packet.Presence;
import org.jxmpp.jid.BareJid;
import org.jxmpp.jid.Jid;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.util.ArrayList;
import java.util.Base64;
import java.util.HashMap;
import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;

public class storage extends AppCompatActivity
{
    public static HashMap<BareJid, ArrayList<MessageData>> jidsToMessages;
    public static HashMap<BareJid, Presence> friends;
    public static ArrayList<GroupChatData> groupChats;
    public static HashMap<BareJid, byte[]> friendRequests;
    public static String username;
    public static String privKeyEncoded;
    public static String pubKeyEncoded;
    public static Context context;



    public static void Initialize(Context cont) throws NoSuchPaddingException, NoSuchAlgorithmException
    {
        context = cont;
        friends = new HashMap<BareJid, Presence>();
        friendRequests = new HashMap<BareJid, byte[]>();
        jidsToMessages = new HashMap<BareJid, ArrayList<MessageData>>();
        groupChats = new ArrayList<GroupChatData>();
    }

    public static void createFileInContextDirectory(String fileName)
    {

        File directory = context.getFilesDir();
        File file = new File(directory, fileName);
        try
        {
            if (!file.exists())
            {
                boolean created = file.createNewFile();
                if (!created)
                {
                    throw new RuntimeException(fileName+" FILE NOT CREATED");
                }
            }
        } catch (IOException e)
        {
            throw new RuntimeException(fileName+" FILE NOT CREATED");
        }
    }

    public static void generateKeyPair() throws NoSuchAlgorithmException
    {
        RSA rsa = new RSA();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
        {
            privKeyEncoded = Base64.getEncoder().encodeToString(rsa.getPrivate().getEncoded());
            pubKeyEncoded = Base64.getEncoder().encodeToString(rsa.getPublic().getEncoded());
        }
    }

    public static void wipe()
    {
        jidsToMessages.clear();
        friendRequests.clear();
        friends.clear();
        groupChats.clear();
        privKeyEncoded=null;
        pubKeyEncoded=null;
        context=null;
        username=null;
    }

    public static void writePrivKeyToFile()
    {
        try
        {
            OutputStreamWriter outputStreamWriter = new OutputStreamWriter(context.openFileOutput(username+"private.key", Context.MODE_PRIVATE));
            outputStreamWriter.write(privKeyEncoded);
            outputStreamWriter.close();
        }
        catch (IOException e)
        {
            System.out.println("Unable to write to file");
        }
    }

    public static String readPrivKeyFromFile()
    {
        String ret = "";
        try
        {
            InputStream inputStream = context.openFileInput(username+"private.key");
            if ( inputStream != null ) {
                InputStreamReader inputStreamReader = new InputStreamReader(inputStream);
                BufferedReader bufferedReader = new BufferedReader(inputStreamReader);
                String receiveString;
                StringBuilder stringBuilder = new StringBuilder();
                while ((receiveString = bufferedReader.readLine()) != null) {
                    stringBuilder.append(receiveString);
                }
                inputStream.close();
                ret = stringBuilder.toString();
            }
        }
        catch (FileNotFoundException e)
        {
            System.out.println("login activity" + "File not found: " + e.toString());
        } catch (IOException e)
        {
            System.out.println("login activity" + "Can not read file: " + e.toString());
        }
        return ret;
    }

    public static void writeFriendsAesKeyToFile(boolean pending, String jid, String base64key)
    {
        try
        {
            OutputStreamWriter outputStreamWriter = new OutputStreamWriter(context.openFileOutput(username+"friends.txt", Context.MODE_APPEND));
            outputStreamWriter.write(pending+":"+jid+":"+base64key+"\n");
            outputStreamWriter.close();
        }
        catch (IOException e)
        {
            throw new RuntimeException(e);
        }
    }

    public static void writeGroupChatInfoToFile(boolean pending, String roomname, String invitor, String key)
    {
        try
        {
            OutputStreamWriter outputStreamWriter = new OutputStreamWriter(context.openFileOutput(username+"groups.txt", Context.MODE_PRIVATE));
            outputStreamWriter.append(pending+":"+roomname+":"+invitor+":"+key+"\n");
            outputStreamWriter.close();
        }
        catch (IOException e)
        {
            System.out.println("Unable to write to file");
        }
    }



    public static void clearFile(OutputStream os)
    {

        try
        {
            OutputStreamWriter osw = new OutputStreamWriter(os);
            osw.write("");
            osw.close();
        }catch (IOException e)
        {
            // nothing for now
        }

    }

    public static String readFriendKeyFromFile(Jid jid)
    {
        try
        {
            InputStream inputStream = context.openFileInput(username+"friends.txt");
            if (inputStream != null)
            {
                InputStreamReader inputStreamReader = new InputStreamReader(inputStream);
                BufferedReader bufferedReader = new BufferedReader(inputStreamReader);
                String receiveString;
                while ((receiveString = bufferedReader.readLine()) != null)
                {
                    String[] arr = receiveString.split(":");
                    if(arr[1].equals(jid.toString()))
                    {
                        return arr[2];
                    }
                }
                inputStream.close();
            }
            return "Couldn't Find Friends Key";
        } catch (IOException e)
        {
            throw new RuntimeException(e);
        }
    }

    public static String readGroupKeyFromFile(String jid)
    {
        try
        {
            InputStream inputStream = context.openFileInput(username+"groups.txt");
            if (inputStream != null)
            {
                InputStreamReader inputStreamReader = new InputStreamReader(inputStream);
                BufferedReader bufferedReader = new BufferedReader(inputStreamReader);
                String receiveString;
                while ((receiveString = bufferedReader.readLine()) != null)
                {
                    String[] arr = receiveString.split(":");
                    if(arr[1].equals(jid.toString()))
                    {
                        return arr[3];
                    }
                }
                inputStream.close();
            }
            return "Couldn't Find Group Key";
        } catch (IOException e)
        {
            throw new RuntimeException(e);
        }
    }

    public static void readFile(String filename)
    {
        StringBuilder stringBuilder = new StringBuilder();
        try {
            FileInputStream fileInputStream = context.openFileInput(filename);
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(fileInputStream));
            String receiveString;
            while ((receiveString = bufferedReader.readLine()) != null)
            {
                stringBuilder.append(receiveString).append("\n");
            }
            fileInputStream.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        System.out.println(stringBuilder.toString());
    }

    public static ArrayList<GroupChatData> getGroupChatsFromFile(String filename)
    {
        ArrayList<GroupChatData> output = new ArrayList<GroupChatData>();
        try
        {
            FileInputStream fileInputStream = context.openFileInput(filename);
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(fileInputStream));
            String receiveString;
            while ((receiveString = bufferedReader.readLine()) != null)
            {
                String[] arr = receiveString.split(":");
                output.add(new GroupChatData(Boolean.parseBoolean(arr[0]), arr[1], arr[2], arr[3]));
            }
            fileInputStream.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return output;
    }

    public static void editGroupChatLine(String pending, String fullGroupChatJid)
    {
        String searchTerm = fullGroupChatJid;
        File file = new File(context.getFilesDir(), username+"groups.txt");
        try
        {
            BufferedReader br = new BufferedReader(new FileReader(file));
            StringBuilder sb = new StringBuilder();
            String line;
            boolean lineFound = false; // Flag to indicate if the line was found
            while ((line = br.readLine()) != null)
            {
                String[] parts = line.split(":");
                if (parts[1].equals(searchTerm))
                {
                    // Found the line
                    byte[] aesKey = RSA.Decrypt(parts[3], privKeyEncoded);
                    String encodedAesKey=null;
                    if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O)
                    {
                        encodedAesKey = Base64.getEncoder().encodeToString(aesKey);
                    }
                    sb.append(pending+":"+fullGroupChatJid+":"+parts[2]+":"+encodedAesKey+"\n");
                    lineFound = true; // Set the flag to indicate that the line was found
                } else
                {
                    sb.append(line); // Keep the original line
                }
            }
            br.close();
            if (!lineFound)
            {
                System.out.println("GROUP NOT IN FILE");
            }
            FileOutputStream outputStream = new FileOutputStream(file, false); // Overwrite the file
            outputStream.write(sb.toString().getBytes());
            outputStream.close();
        } catch (IOException | NoSuchPaddingException | InvalidKeyException |
                 InvalidKeySpecException | BadPaddingException | NoSuchAlgorithmException |
                 IllegalBlockSizeException e) {
            throw new RuntimeException(e);
        }

    }

    public static void deleteGroupChatLine(String fullGroupChatJid)
    {
        String searchTerm = fullGroupChatJid;
        File file = new File(context.getFilesDir(), username+"groups.txt");
        try
        {
            BufferedReader br = new BufferedReader(new FileReader(file));
            StringBuilder sb = new StringBuilder();
            String line;
            boolean lineFound = false; // Flag to indicate if the line was found
            while ((line = br.readLine()) != null)
            {
                String[] parts = line.split(":");
                if (!parts[1].equals(searchTerm))
                {
                    sb.append(line);
                }
            }
            br.close();
            if (!lineFound)
            {
                System.out.println("GROUP NOT IN FILE");
            }
            FileOutputStream outputStream = new FileOutputStream(file, false); // Overwrite the file
            outputStream.write(sb.toString().getBytes());
            outputStream.close();
        } catch (IOException e)
        {
            throw new RuntimeException(e);
        }
    }







}
