package com.example.selfdestructim;
import android.content.Intent;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.PopupWindow;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;

public class AdapterForGroupChatInvites extends RecyclerView.Adapter<AdapterForGroupChatInvites.ViewHolder>
{
    private ArrayList<GroupChatData> groupChatInvs;
    public AdapterForGroupChatInvites(ArrayList<GroupChatData> groupChatInvs)
    {
        this.groupChatInvs=groupChatInvs;
    }

    @NonNull
    @Override
    public AdapterForGroupChatInvites.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType)
    {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.group_chat_item, parent,false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull AdapterForGroupChatInvites.ViewHolder holder, int position)
    {
        String groupChatName = groupChatInvs.get(position).getGroupChatName();
        String groupChatInvitor = groupChatInvs.get(position).getInvitorsName();
        String groupChatKey = groupChatInvs.get(position).getKey();
        boolean pending = groupChatInvs.get(position).getPending();
        holder.setData(pending, groupChatName, groupChatInvitor, groupChatKey);
    }

    @Override
    public int getItemCount()
    {
        return groupChatInvs.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder
    {
        private TextView groupChatName;
        private ImageButton popUpButton;

        public ViewHolder(@NonNull View itemView)
        {
            super(itemView);
            popUpButton = itemView.findViewById(R.id.makePopUpWindow);
            groupChatName = itemView.findViewById(R.id.groupChatName);
        }

        public void setData(boolean pending, String name, String invitor, String groupchatKey)
        {
            groupChatName.setText(name.replace("@conference.cipher.com", ""));
            if(pending)
            {
                View popupView =  LayoutInflater.from(storage.context).inflate(R.layout.popup_for_muc_invite, null);
                TextView invtr = popupView.findViewById(R.id.mucInvitor);
                TextView key = popupView.findViewById(R.id.textViewforKey);
                ImageButton accept = popupView.findViewById(R.id.groupChatAccept);
                ImageButton deny = popupView.findViewById(R.id.groupChatDeny);

                accept.setOnClickListener(new View.OnClickListener()
                {
                    @Override
                    public void onClick(View view)
                    {
                        storage.editGroupChatLine("false", name);
                        popUpButton.setEnabled(false);
                        popUpButton.setVisibility(View.GONE);
                        popupView.setVisibility(View.GONE);
                        itemView.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {

                                Intent intent = new Intent(itemView.getContext(), talkingInGroupChat.class);
                                intent.putExtra("groupname", name);
                                itemView.getContext().startActivity(intent);
                            }
                        });
                    }
                });

                deny.setOnClickListener(new View.OnClickListener()
                {
                    @Override
                    public void onClick(View view)
                    {
                        storage.deleteGroupChatLine(name);
                        for(GroupChatData d: groupChatInvs)
                        {
                            if(d.getGroupChatName().equals(name))
                            {
                                int i = groupChatInvs.indexOf(d);
                                storage.groupChats.remove(i);
                                notifyItemRemoved(i);
                                break;
                            }
                        }

                    }
                });

                invtr.setText("From: "+invitor);
                key.setText("Key: "+groupchatKey);
                PopupWindow popUpWindow = new PopupWindow(popupView, ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                popUpButton.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view)
                    {
                        popUpWindow.setOutsideTouchable(true);
                        popUpWindow.setFocusable(true);
                        popUpWindow.showAtLocation(view, Gravity.CENTER, 0, 0);
                    }
                });
            }
            else
            {
                popUpButton.setEnabled(false);
                popUpButton.setVisibility(View.GONE);
                itemView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {

                        Intent intent = new Intent(itemView.getContext(), talkingInGroupChat.class);
                        intent.putExtra("groupname", name);
                        itemView.getContext().startActivity(intent);
                    }
                });
            }

        }
    }

}