package com.example.selfdestructim;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import org.jivesoftware.smack.SmackException;
import org.jivesoftware.smack.XMPPException;
import org.jivesoftware.smackx.muc.MultiUserChatException;
import org.jxmpp.jid.BareJid;
import org.jxmpp.stringprep.XmppStringprepException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Locale;
import java.util.concurrent.ExecutionException;
import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;

public class GroupChats extends Fragment
{
    private SpinnerAdapter adapterSpin;
    private Spinner spinner;
    private Button createGroupChatButton;
    private EditText roomName;
    private RecyclerView groupChatInvs;
    private LinearLayoutManager linLayout;
    private ArrayList<GroupChatData> inviteData;
    private AdapterForGroupChatInvites adapterRecyc;

    public static Handler newInvHandler;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState)
    {
        View view = inflater.inflate(R.layout.fragment_groupchats, container, false);
        ArrayList<BareJid> spinnerData =  new ArrayList<BareJid>();
        spinnerData.addAll(storage.friends.keySet());

        groupChatInvs = (RecyclerView) view.findViewById(R.id.groupChatRecycView);
        spinner = (Spinner) view.findViewById(R.id.spinnerForAddingFriendsToChats);
        createGroupChatButton = view.findViewById(R.id.createChatRoom);
        roomName = view.findViewById(R.id.enterGroupChatName);
        adapterSpin = new SpinnerAdapter(getContext(), spinnerData);
        spinner.setAdapter(adapterSpin);

        initData();
        initRecyclerView();

        newInvHandler= new Handler(Looper.getMainLooper())
        {
            @Override
            public void handleMessage(Message msg)
            {
                initRecyclerView();
            }
        };

        createGroupChatButton.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                SpinnerAdapter sa = (SpinnerAdapter) spinner.getAdapter();
                byte[] aesKey = AES.generateKey().getEncoded();
                byte[] iv = AES.generateIv().getIV();
                byte[] concat = new byte[32];
                for(int i =0; i<concat.length; i++)
                {
                    if(i<16)
                    {
                        concat[i] = aesKey[i];
                    }
                    else
                    {
                        concat[i] = iv[i-16];
                    }
                }

                String keyForMe = null;
                if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O)
                {
                    keyForMe = Base64.getEncoder().encodeToString(concat);
                }

                ArrayList<String> secretKeys = new ArrayList<String>();
                for(BareJid b : sa.getInvitees())
                {
                    try
                    {
                        String friendPublicKey = new HttpRequests().execute("getUserKey", b.toString().replace("@cipher.com", "")).get();
                        String secretKey = RSA.Encrypt(concat, friendPublicKey);
                        secretKeys.add(secretKey);
                    } catch (ExecutionException | InterruptedException | NoSuchPaddingException |
                             IllegalBlockSizeException | NoSuchAlgorithmException |
                             BadPaddingException | InvalidKeySpecException | InvalidKeyException e) {
                        throw new RuntimeException(e);
                    }
                }

                String roomTitle = roomName.getText().toString().toLowerCase();

                try
                {
                    XMPPConnection.createChatRoom(roomTitle, storage.username, sa.getInvitees(), secretKeys);
                    storage.writeGroupChatInfoToFile(false, roomTitle+"@conference.cipher.com", storage.username+"@cipher.com", keyForMe);
                    storage.groupChats.add(new GroupChatData(false, roomTitle+"@conference.cipher.com", storage.username+"@cipher.com", keyForMe));
                    adapterRecyc.notifyItemInserted(storage.groupChats.size()-1);
                    roomName.setText("");
                    Toast.makeText(storage.context, "Invite(s) sent", Toast.LENGTH_SHORT).show();
                } catch (XmppStringprepException | XMPPException.XMPPErrorException |
                         SmackException.NotConnectedException | SmackException.NoResponseException |
                         InterruptedException | MultiUserChatException.NotAMucServiceException e) {
                    throw new RuntimeException(e);
                }

            }
        });

        return view;
    }

    private void initData()
    {
        inviteData = storage.groupChats;
    }

    private void initRecyclerView()
    {
        linLayout = new LinearLayoutManager(getContext());
        linLayout.setOrientation(RecyclerView.VERTICAL);
        groupChatInvs.setLayoutManager(linLayout);
        adapterRecyc = new AdapterForGroupChatInvites(inviteData);
        groupChatInvs.setAdapter(adapterRecyc);
        adapterRecyc.notifyDataSetChanged();
    }

}