package com.example.selfdestructim;

public class ModelClass
{
    private int imageView1;
    private String textview1;
    private String textview2;
    private String textview3;
    private String divider;

    public ModelClass(int image1, String text1, String text2, String text3, String div)
    {
        imageView1 = image1;
        textview1 = text1;
        textview2 = text2;
        textview3 = text3;
        divider = div;
    }

    public int getImageView1() {
        return imageView1;
    }

    public String getTextview1() {
        return textview1;
    }

    public String getTextview2() {
        return textview2;
    }

    public String getTextview3() {
        return textview3;
    }

    public String getDivider() {
        return divider;
    }
}
