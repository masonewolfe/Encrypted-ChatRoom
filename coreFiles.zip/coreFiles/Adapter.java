package com.example.selfdestructim;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import org.w3c.dom.Text;
import java.util.List;

public class Adapter extends RecyclerView.Adapter<Adapter.ViewHolder>
{
    private List<ModelClass> userList;
    public Adapter(List<ModelClass>userList){this.userList = userList;}

    @NonNull
    @Override
    public Adapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view= LayoutInflater.from(parent.getContext()).inflate(R.layout.item_design, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull Adapter.ViewHolder holder, int position)
    {
        int resource=userList.get(position).getImageView1();
        String name = userList.get(position).getTextview1();
        String msg = userList.get(position).getTextview3();
        String time = userList.get(position).getTextview2();
        String line = userList.get(position).getDivider();

        holder.setData(resource,name,msg,time,line);


    }

    @Override
    public int getItemCount() {
        return userList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder
    {
        private ImageView image;
        private TextView text1;
        private TextView text2;
        private TextView text3;
        private TextView div;



        public ViewHolder(@NonNull View itemView)
        {
            super(itemView);
            image=itemView.findViewById(R.id.imageview1);
            text1=itemView.findViewById(R.id.textview);
            text2=itemView.findViewById(R.id.textview2);
            text3=itemView.findViewById(R.id.textview3);
            div=itemView.findViewById(R.id.textview4);
        }

        public void setData(int resource, String name, String msg, String time, String line)
        {
            image.setImageResource(resource);
            text1.setText(name);
            text3.setText(msg);
            text2.setText(time);
            div.setText(line);
        }
    }
}
