package com.example.selfdestructim;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import java.io.IOException;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

public class userInfo extends AppCompatActivity
{

    private EditText username;
    private EditText password;
    private EditText email;
    private Button submit;


    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_info);

        submit = (Button) findViewById(R.id.submitUserInfo);
        submit.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                username = findViewById(R.id.username);
                password = findViewById(R.id.password);
                email = findViewById(R.id.email);

                new Thread()
                {
                    @Override
                    public void run()
                    {
                        try
                        {
                            createUser(username.getText().toString(), password.getText().toString());
                        } catch (IOException e) {
                            throw new RuntimeException("There was an Error registering");
                        }
                    }
                }.start();

                Intent intent = new Intent(userInfo.this, UserHome.class);
                startActivity(intent);

            }
        });
    }

    private boolean checkForValidEmail(String email)
    {
        boolean hasAt = false;
        boolean hasDomain = false;
        if(email.contains("@"))
        {
            hasAt = true;
        }
        if(email.contains(".com") || email.contains(".org") || email.contains(".edu") || email.contains(".net") || email.contains(".gov"))
        {
            hasDomain = true;
        }
        return (hasAt&&hasDomain);
    }

    private boolean checkForValidUsername(String username)
    {
        boolean isValid = true;
        for(int i=0; i<username.length(); i++)
        {
            int ascii = (int) username.charAt(i);
            if (!((ascii >= 65 && ascii <=90) || (ascii>=97 && ascii <=122) || (ascii >=48 && ascii<=57) || ascii == 45 || ascii == 95))
            {
                isValid = false;
                break;
            }
        }
        return isValid;
    }

    private boolean checkForValidPassword(String password)
    {
        boolean isLong = false;
        boolean hasCap = false;
        boolean hasLow = false;
        boolean hasNum = false;

        if(password.length()>=8)
        {
            isLong = true;
        }else{return false;}

        for(int i =0; i<password.length(); i++)
        {
            int ascii = password.charAt(i);
            if(ascii>=65 && ascii<=90)
            {
                hasCap = true;
            }
            if(ascii>=97 && ascii<=122)
            {
                hasLow = true;
            }
            if(ascii>=48 && ascii<=57)
            {
                hasNum = true;
            }
        }
        return (isLong && hasCap && hasLow && hasNum);
    }

    private int createUser(String usr, String pwd) throws IOException
    {
        String[] ids = {"user", "host", "password"};
        String[] vals = {usr, "selfdestructim.com", pwd};
        jsonObj json = new jsonObj(ids, vals);
        System.out.println(json.toString());
        URL url = new URL("http://52.188.65.46:5281/api/register");
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("POST");
        conn.setDoOutput(true);
        OutputStream os = conn.getOutputStream();
        os.write(json.toString().getBytes(StandardCharsets.UTF_8));
        int responseCode = conn.getResponseCode();
        return responseCode;
    }


}