package com.example.selfdestructim;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.fasterxml.jackson.core.JsonEncoding;
import com.fasterxml.jackson.core.JsonFactory;
import com.fasterxml.jackson.core.JsonGenerator;

import org.jivesoftware.smack.AbstractXMPPConnection;
import org.jivesoftware.smack.ConnectionConfiguration;
import org.jivesoftware.smack.SmackException;
import org.jivesoftware.smack.XMPPException;
import org.jivesoftware.smack.chat.Chat;
import org.jivesoftware.smack.chat.ChatManagerListener;
import org.jivesoftware.smack.chat.ChatMessageListener;
import org.jivesoftware.smack.chat2.ChatManager;
import org.jivesoftware.smack.chat2.IncomingChatMessageListener;
import org.jivesoftware.smack.packet.Message;
import org.jivesoftware.smack.tcp.XMPPTCPConnection;
import org.jivesoftware.smack.tcp.XMPPTCPConnectionConfiguration;
import org.json.JSONException;
import org.json.JSONObject;
import org.jxmpp.jid.DomainBareJid;
import org.jxmpp.jid.EntityBareJid;
import org.jxmpp.jid.impl.JidCreate;
import org.jxmpp.stringprep.XmppStringprepException;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.math.BigInteger;
import java.net.HttpURLConnection;
import java.net.InetAddress;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.UnknownHostException;
import java.nio.charset.StandardCharsets;
import java.security.NoSuchAlgorithmException;

import javax.net.ssl.HostnameVerifier;

public class loginAttempt extends AppCompatActivity
{

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.sign_in);
        Button login = (Button) findViewById(R.id.loginButton);
        EditText username = findViewById(R.id.usernameLogin);
        EditText password = findViewById(R.id.passwordLogin);
        login.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                new Thread()
                {
                    @Override
                    public void run()
                    {
                        try
                        {
                            InetAddress addr = InetAddress.getByName("52.188.65.46");
                            HostnameVerifier verifier = (hostname, session) -> false;
                            DomainBareJid serviceName = JidCreate.domainBareFrom("selfdestructim.com");
                            XMPPTCPConnectionConfiguration config = XMPPTCPConnectionConfiguration.builder()
                                    .setUsernameAndPassword(username.getText().toString(), password.getText().toString())
                                    .setPort(5222)
                                    .setSecurityMode(ConnectionConfiguration.SecurityMode.disabled)
                                    .setXmppDomain(serviceName)
                                    .setHostnameVerifier(verifier)
                                    .setHostAddress(addr)
                                    .setSendPresence(true)
                                    .build();
                            Connection.setCon(config);
                            handleKey(username.getText().toString());
                            Intent intent = new Intent(loginAttempt.this, UserHome.class);
                            startActivity(intent);
                        }
                        catch (Exception e)
                        {
                            throw new RuntimeException("Connection Could not be established");
                        }
                    }
                }.start();
            }
        });
    }

    public int handleKey(String username) throws NoSuchAlgorithmException, IOException, JSONException
    {
        RSA rsa = new RSA();
        String pubkey = new BigInteger(rsa.getPublic().getEncoded()).toString();
        Connection.setKey(rsa.getPrivate());

        String[] ids = {"username", "publickey"};
        String[] vals = {username, pubkey};
        jsonObj json = new jsonObj(ids, vals);
        System.out.println(json.toString());

        URL url = new URL("http://52.188.65.46:5000/update");
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("PUT");
        conn.setDoOutput(true);

        OutputStream os = conn.getOutputStream();
        os.write(json.toString().getBytes(StandardCharsets.UTF_8));
        return 1;
    }

}
