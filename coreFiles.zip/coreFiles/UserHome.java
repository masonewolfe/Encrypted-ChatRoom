package com.example.selfdestructim;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

public class UserHome extends AppCompatActivity
{
    RecyclerView recyclerView1;
    LinearLayoutManager layoutmanager;
    List<ModelClass> userList = new ArrayList<>();
    Adapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_home);

        EditText talkTo = findViewById(R.id.newThreadUsername);
        Button addThread = (Button) findViewById(R.id.newThread);

        addThread.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    userList.add(new ModelClass(R.drawable.stockprofile, talkTo.getText().toString(), LocalTime.now().toString(), "", "---------------------------------------------"));
                }
            }
        });

        initRecyclerView();


    }

    private void initRecyclerView() {
        recyclerView1=findViewById(R.id.recyclerView);
        recyclerView1.addOnItemTouchListener(
                new RecyclerItemClickListener(this, recyclerView1 ,new RecyclerItemClickListener.OnItemClickListener() {
                    @Override public void onItemClick(View view, int position)
                    {
                        Intent intent = new Intent(UserHome.this, sendMessage.class);
                        intent.putExtra("name", userList.get(position).getTextview1());
                        startActivity(intent);
                    }

                    @Override public void onLongItemClick(View view, int position) {
                        // do whatever
                    }
                })
        );
        layoutmanager = new LinearLayoutManager(this);
        layoutmanager.setOrientation(RecyclerView.VERTICAL);
        recyclerView1.setLayoutManager(layoutmanager);
        adapter=new Adapter(userList);
        recyclerView1.setAdapter(adapter);
        adapter.notifyDataSetChanged();
    }
}