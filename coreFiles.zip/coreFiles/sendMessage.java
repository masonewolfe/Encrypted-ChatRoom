package com.example.selfdestructim;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import org.jivesoftware.smack.chat2.Chat;
import org.jivesoftware.smack.chat2.ChatManager;
import org.jivesoftware.smack.chat2.IncomingChatMessageListener;
import org.jivesoftware.smack.packet.Message;
import org.jxmpp.jid.EntityBareJid;
import org.jxmpp.jid.impl.JidCreate;

public class sendMessage extends AppCompatActivity
{
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.sending_messages);
        Intent intent = getIntent();
        String toWho = intent.getStringExtra("name");
        TextView person = (TextView) findViewById(R.id.whoSend);
        EditText msg = findViewById(R.id.message);
        person.setText(toWho);
        Button send = (Button) findViewById(R.id.send);
        ChatManager chatManager = ChatManager.getInstanceFor(Connection.con);

        chatManager.addIncomingListener(new IncomingChatMessageListener()
        {
            @Override
            public void newIncomingMessage(EntityBareJid from, Message message, org.jivesoftware.smack.chat2.Chat chat)
            {
                System.out.println("New message from " + from + ": " + message.getBody());
            }
        });

        send.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                try
                {
                    EntityBareJid jid = JidCreate.entityBareFrom(toWho+"@selfdestructim.com");
                    Chat chat = chatManager.chatWith(jid);
                    if(msg.getText().toString()!="")
                    {
                        chat.send(msg.getText().toString());
                    }
                }catch(Exception e)
                {

                }
            }
        });



    }
}
