package com.example.selfdestructim;
import org.jivesoftware.smack.AbstractXMPPConnection;
import org.jivesoftware.smack.SmackException;
import org.jivesoftware.smack.XMPPException;
import org.jivesoftware.smack.tcp.XMPPTCPConnection;
import org.jivesoftware.smack.tcp.XMPPTCPConnectionConfiguration;

import java.io.IOException;
import java.security.PrivateKey;

public class Connection
{
    public static AbstractXMPPConnection con;
    public static PrivateKey secret;

    public static void setCon(XMPPTCPConnectionConfiguration config) throws SmackException, IOException, XMPPException, InterruptedException
    {
        con = new XMPPTCPConnection(config);
        con.connect();
        con.login();
    }

    public static void setKey(PrivateKey k)
    {
        secret = k;
    }
}
